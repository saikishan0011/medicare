import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicare',
  templateUrl: './medicare.component.html',
  styleUrls: ['./medicare.component.css']
})
export class MedicareComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
