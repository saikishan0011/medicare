export class UserClass{
    id:number
    name:String
    description:any
    quantity:any
    price:any


}
