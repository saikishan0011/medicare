import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-antipiretics',
  templateUrl: './antipiretics.component.html',
  styleUrls: ['./antipiretics.component.css']
})
export class AntipireticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
